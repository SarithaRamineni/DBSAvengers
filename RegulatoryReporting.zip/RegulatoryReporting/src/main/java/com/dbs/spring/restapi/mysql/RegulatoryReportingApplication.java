package com.dbs.spring.restapi.mysql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegulatoryReportingApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegulatoryReportingApplication.class, args);
	}

}
